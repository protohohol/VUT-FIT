<?php

declare(strict_types=1);

use Latte\Runtime as LR;

/** source: /home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/Systeminfo/default.latte */
final class Templatecb1b085936 extends Latte\Runtime\Template
{
	public const Source = '/home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/Systeminfo/default.latte';

	public const Blocks = [
		0 => ['content' => 'blockContent', 'systemInfoSnippet' => 'blockSystemInfoSnippet', 'scripts' => 'blockScripts'],
		'snippet' => ['flashMessages' => 'blockFlashMessages', 'renderDefault' => 'blockRenderDefault', 'systemEditForm' => 'blockSystemEditForm'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('content', get_defined_vars()) /* line 2 */;
		echo '




';
		$this->renderBlock('scripts', get_defined_vars()) /* line 33 */;
	}


	public function prepare(): array
	{
		extract($this->params);

		if (!$this->getReferringTemplate() || $this->getReferenceType() === 'extends') {
			foreach (array_intersect_key(['flash' => '5'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		$this->parentName = '../@layout.latte';
		return get_defined_vars();
	}


	/** {block content} on line 2 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <!-- Flash Messages -->
    ';
		echo '<div id="', htmlspecialchars($this->global->snippetDriver->getHtmlId('flashMessages')), '">';
		$this->renderBlock('flashMessages', [], null, 'snippet') /* line 4 */;
		echo '</div>

    <!-- System Information (Dynamically Updated) -->
    ';
		echo '<div id="', htmlspecialchars($this->global->snippetDriver->getHtmlId('renderDefault')), '">';
		$this->renderBlock('renderDefault', [], null, 'snippet') /* line 11 */;
		echo '</div>

    <!-- System Edit Form -->
    ';
		echo '<div id="', htmlspecialchars($this->global->snippetDriver->getHtmlId('systemEditForm')), '">';
		$this->renderBlock('systemEditForm', [], null, 'snippet') /* line 15 */;
		echo '</div>
';
	}


	/** {snippet flashMessages} on line 4 */
	public function blockFlashMessages(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		$this->global->snippetDriver->enter('flashMessages', 'static') /* line 4 */;
		try {
			echo "\n";
			foreach ($flashes as $flash) /* line 5 */ {
				echo '            <div class="alert alert-';
				echo LR\Filters::escapeHtmlAttr($flash->type) /* line 6 */;
				echo '">';
				echo LR\Filters::escapeHtmlText($flash->message) /* line 6 */;
				echo '</div>
';

			}

			echo '    ';

		} finally {
			$this->global->snippetDriver->leave();
		}
	}


	/** {snippet renderDefault} on line 11 */
	public function blockRenderDefault(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		$this->global->snippetDriver->enter('renderDefault', 'static') /* line 11 */;
		try {
			echo '
    ';

		} finally {
			$this->global->snippetDriver->leave();
		}
	}


	/** {snippet systemEditForm} on line 15 */
	public function blockSystemEditForm(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		$this->global->snippetDriver->enter('systemEditForm', 'static') /* line 15 */;
		try {
			echo "\n";
			$this->renderBlock('systemInfoSnippet', get_defined_vars(), 'html') /* line 16 */;
			$ʟ_tmp = $this->global->uiControl->getComponent('systemEditForm');
			if ($ʟ_tmp instanceof Nette\Application\UI\Renderable) $ʟ_tmp->redrawControl(null, false);
			$ʟ_tmp->render() /* line 17 */;

			echo '    ';

		} finally {
			$this->global->snippetDriver->leave();
		}
	}


	/** {define systemInfoSnippet} on line 22 */
	public function blockSystemInfoSnippet(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		if ($system) /* line 23 */ {
			echo '        <h2>';
			echo LR\Filters::escapeHtmlText($system->system_name) /* line 24 */;
			echo '</h2>
        <p>';
			echo LR\Filters::escapeHtmlText($system->system_description) /* line 25 */;
			echo '</p>
';
		} else /* line 26 */ {
			echo '        <p>System information is not available.</p>
';
		}
	}


	/** {block scripts} on line 33 */
	public function blockScripts(array $ʟ_args): void
	{
		echo '    <script>
        console.log(\'default.latte script is running\');
        document.addEventListener(\'DOMContentLoaded\', function() {
            console.log(\'DOM fully loaded and parsed\');

            naja.addEventListener(\'before\', (event) => {
                console.log(\'Before AJAX request is sent\', event);
            });

            naja.addEventListener(\'success\', (event) => {
                console.log(\'AJAX request successful\', event);
            });

            naja.addEventListener(\'error\', (event) => {
                console.log(\'AJAX request failed\', event);
            });

            naja.snippetHandler.addEventListener(\'afterUpdate\', function (event) {
                if (event.snippet.id === \'flashMessages\') {
                    // Additional JS if needed when flash messages are updated
                }
            });
        });
    </script>
';
	}
}
