<?php

declare(strict_types=1);

use Latte\Runtime as LR;

/** source: /home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/UserSystems/default.latte */
final class Templateca4e274a59 extends Latte\Runtime\Template
{
	public const Source = '/home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/UserSystems/default.latte';

	public const Blocks = [
		['content' => 'blockContent'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
	}


	public function prepare(): array
	{
		extract($this->params);

		if (!$this->getReferringTemplate() || $this->getReferenceType() === 'extends') {
			foreach (array_intersect_key(['userSystem' => '9'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		return get_defined_vars();
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <h1>User Systems</h1>
    <div class="user-info" style="float: right; margin-top: -15px;">
        <span>Vítejte, ';
		echo LR\Filters::escapeHtmlText($presenter->user->getIdentity()->username) /* line 4 */;
		echo '</span>
        <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Signout:default')) /* line 5 */;
		echo '">Odhlásit se</a>
    </div>

    <ul>
';
		foreach ($user->related('UserSystems') as $userSystem) /* line 9 */ {
			echo '            <li>
                <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Systeminfo:default', [$userSystem->system->system_id])) /* line 11 */;
			echo '">
                    ';
			echo LR\Filters::escapeHtmlText($userSystem->system->system_name) /* line 12 */;
			echo '
                </a>
            </li>
';

		}

		echo '    </ul>

    <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('createSystemForm')) /* line 18 */;
		echo '">Create New System</a>

    
';
	}
}
