<?php

declare(strict_types=1);

use Latte\Runtime as LR;

/** source: /home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/@layout.latte */
final class Templatee234e5a81c extends Latte\Runtime\Template
{
	public const Source = '/home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/@layout.latte';

	public const Blocks = [
		['content' => 'blockContent', 'scripts' => 'blockScripts'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>';
		if (isset($title)) /* line 6 */ {
			echo LR\Filters::escapeHtmlText($title) /* line 6 */;
		} else /* line 6 */ {
			echo 'Hell Yeah';
		}
		echo '</title>
       <style>
        body {
            background-color: #1a1a1a; /* Dark background color */
            color: #ff3333; /* Fiery red text color */
            font-family: \'Creepster\', cursive; /* Eerie font */
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #1a1a1a;
            padding: 20px;
            text-align: center;
        }

        nav {
            background-color: #1a1a1a;
            text-align: center;
            padding: 10px;
        }

        nav a {
            color: #ff3333;
            text-decoration: none;
            margin: 0 10px;
        }

        main {
            background-color: #222222; /* Dark gray content background */
            padding: 20px;
        }

        footer {
            background-color: #1a1a1a;
            text-align: center;
            padding: 10px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to the Gym</h1>
    </header>

    <nav>
        <a href="/">Home</a>
        <a href="/about">About</a>
        <a href="/contact">Contact</a>
    </nav>

    <main>
';
		$this->renderBlock('content', get_defined_vars()) /* line 59 */;
		echo '    </main>

    <footer>
        &copy; ';
		echo LR\Filters::escapeHtmlText(date('Y')) /* line 65 */;
		echo ' Hellish Website. All souls reserved.
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://unpkg.com/naja@2/dist/Naja.min.js"></script>
    <script>
    document.addEventListener(\'DOMContentLoaded\', naja.initialize.bind(naja));
    </script>
';
		$this->renderBlock('scripts', get_defined_vars()) /* line 73 */;
		echo '</body>
</html>';
	}


	/** {block content} on line 59 */
	public function blockContent(array $ʟ_args): void
	{
		echo '        <p>Welcome to the darkest depths of the web.</p>
';
	}


	/** {block scripts} on line 73 */
	public function blockScripts(array $ʟ_args): void
	{
	}
}
