<?php

declare(strict_types=1);

use Latte\Runtime as LR;

/** source: /home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/Admin/dashboard.latte */
final class Template11eaef2ea6 extends Latte\Runtime\Template
{
	public const Source = '/home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/Admin/dashboard.latte';

	public const Blocks = [
		['title' => 'blockTitle', 'content' => 'blockContent'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		echo "\n";
		$this->renderBlock('title', get_defined_vars()) /* line 3 */;
		echo '

';
		$this->renderBlock('content', get_defined_vars()) /* line 5 */;
	}


	public function prepare(): array
	{
		extract($this->params);

		if (!$this->getReferringTemplate() || $this->getReferenceType() === 'extends') {
			foreach (array_intersect_key(['userItem' => '23'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		$this->parentName = '../@layout.latte';
		return get_defined_vars();
	}


	/** {block title} on line 3 */
	public function blockTitle(array $ʟ_args): void
	{
		echo 'Admin Dashboard';
	}


	/** {block content} on line 5 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <h1>Admin Dashboard</h1>
    <p>Vítejte na administračním dashboardu!</p>

    <div class="user-info" style="float: right; margin-top: -15px;">
        <span>Vítejte, ';
		echo LR\Filters::escapeHtmlText($user->getIdentity()->username) /* line 10 */;
		echo '</span>
        <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Signout:default')) /* line 11 */;
		echo '">Odhlásit se</a>
    </div>

';
		$ʟ_tmp = $this->global->uiControl->getComponent('createUserForm');
		if ($ʟ_tmp instanceof Nette\Application\UI\Renderable) $ʟ_tmp->redrawControl(null, false);
		$ʟ_tmp->render() /* line 14 */;

		echo '
    <table>
        <tr>
            <th>Uživatelské jméno</th>
            <th>user_id</th> 
            <th>Role</th>   
            <th>Akce</th>
        </tr>
';
		foreach ($users as $userItem) /* line 23 */ {
			echo '            <tr>
                <td>';
			echo LR\Filters::escapeHtmlText($userItem->username) /* line 25 */;
			echo '</td>
                <td>';
			echo LR\Filters::escapeHtmlText($userItem->user_id) /* line 26 */;
			echo '</td> 
                <td>';
			echo LR\Filters::escapeHtmlText($userItem->role) /* line 27 */;
			echo '</td>   
                <td>
                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('editUserForm', [$userItem->user_id])) /* line 29 */;
			echo '">Upravit</a>
                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('delete', [$userItem->user_id])) /* line 30 */;
			echo '" onclick="return confirm(\'Opravdu chcete smazat tohoto uživatele?\');">Smazat</a>
                </td>
            </tr>
';

		}

		echo '    </table>
';
	}
}
