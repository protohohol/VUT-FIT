<?php

declare(strict_types=1);

use Latte\Runtime as LR;

/** source: /home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/Home/default.latte */
final class Template1a8d0510ba extends Latte\Runtime\Template
{
	public const Source = '/home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/Home/default.latte';

	public const Blocks = [
		['content' => 'blockContent'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		echo "\n";
		$this->renderBlock('content', get_defined_vars()) /* line 3 */;
	}


	public function prepare(): array
	{
		extract($this->params);

		if (!$this->getReferringTemplate() || $this->getReferenceType() === 'extends') {
			foreach (array_intersect_key(['system' => '100'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		$this->parentName = '../@layout.latte';
		return get_defined_vars();
	}


	/** {block content} on line 3 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>IIS Devices from Hell</title>
        <link rel="stylesheet" type="text/css" href="';
		echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 8 */;
		echo '/assets/css/styles.css">
        <style>
            body {
                background-color: #1a0000;
                color: #ff5733;
                font-family: \'Times New Roman\', serif;
            }

            header {
                max-width: 1200px;
                margin: 0 auto;
                height: 100px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                border: 2px solid #ff5733;
                padding: 10px;
                background-color: #1a0000;
            }

            header .logo a {
                padding: 10px;
                background-color: #ff5733;
                color: #fff;
                text-decoration: none;
                border-radius: 5px;
                font-size: 18px;
            }

            main {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                background-color: #1a0000;
                box-shadow: 0 0 10px rgba(255, 87, 51, 0.5);
            }

            h1 {
                color: #ff5733;
            }

            .system-item {
                color: #ff5733;
            }

            footer {
                background-color: #1a0000;
                color: #ff5733;
                text-align: center;
                padding: 10px;
                font-size: 14px;
                border-top: 1px solid #ff5733;
            }

            footer a {
                color: #ff5733;
                text-decoration: none;
            }
        </style>
    </head>

    <body>
        <header>
            <div class="logo">
';
		if ($user->isInRole('admin')) /* line 72 */ {
			echo '                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Admin:dashboard')) /* line 73 */;
			echo '">Admin Dashboard from Hell</a>
';
		}
		echo '            </div>
';
		if (!$user->isLoggedIn()) /* line 76 */ {
			echo '                <div class="signin-button">
                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Signin:default')) /* line 78 */;
			echo '">Login</a>
                </div>
                <div class="signup-button">
                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Signup:default')) /* line 81 */;
			echo '">Register</a>
                </div>
';
		} else /* line 83 */ {
			echo '                <div class="user-info">
                    <span style="color: #ff5733;">Vítejte, ';
			echo LR\Filters::escapeHtmlText($user->getIdentity()->username) /* line 85 */;
			echo '</span>
                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Signout:default')) /* line 86 */;
			echo '">Odhlásit se</a>
                </div>
                <div class="mySystems-buttton">
                    <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('UserSystems:default')) /* line 89 */;
			echo '">My systems</a>
                </div>
';
		}
		echo '        </header>

        <main>
            <h1>Welcome to the Hellish Devices!</h1>
            <div id="system-list">
                <h2>System List from the Abyss</h2>
                <div class="scrollable-list">
';
		if ($systems) /* line 99 */ {
			foreach ($systems as $system) /* line 100 */ {
				echo '                            <div class="system-item">
                                <strong><a href="';
				echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Systeminfo:default', [$system->system_id])) /* line 102 */;
				echo '">';
				echo LR\Filters::escapeHtmlText($system->system_name) /* line 102 */;
				echo '</a></strong> - Owned by: ';
				echo LR\Filters::escapeHtmlText($system->admin->username) /* line 102 */;
				echo '
                            </div>
';

			}

		} else /* line 105 */ {
			echo '                        <p>No systems available in this Desolation.</p>
';
		}
		echo '                </div>
            </div>
        </main>
    </body>
';
	}
}
