<?php

declare(strict_types=1);

use Latte\Runtime as LR;

/** source: /home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/Signin/default.latte */
final class Template70c05ec5e1 extends Latte\Runtime\Template
{
	public const Source = '/home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/Signin/default.latte';

	public const Blocks = [
		['content' => 'blockContent', 'title' => 'blockTitle'],
	];


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		echo "\n";
		$this->renderBlock('content', get_defined_vars()) /* line 3 */;
	}


	public function prepare(): array
	{
		extract($this->params);

		$this->parentName = '../@layout.latte';
		return get_defined_vars();
	}


	/** {block content} on line 3 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);

		echo '    <div class="list-content">
        <div class="home-link">
            <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Home:default')) /* line 6 */;
		echo '">Home</a>
        </div>
        <div class="list-header">
';
		$this->renderBlock('title', get_defined_vars()) /* line 9 */;
		echo '        </div>
        <hr>
        <div>
';
		$ʟ_tmp = $this->global->uiControl->getComponent('signinForm');
		if ($ʟ_tmp instanceof Nette\Application\UI\Renderable) $ʟ_tmp->redrawControl(null, false);
		$ʟ_tmp->render() /* line 13 */;

		echo '        </div>
        <div class="register-link">
            <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('Signup:default')) /* line 16 */;
		echo '">Registrovat se</a>
        </div>
    </div>
';
	}


	/** n:block="title" on line 9 */
	public function blockTitle(array $ʟ_args): void
	{
		echo '            <h1>Přihlaste se</h1>
';
	}
}
