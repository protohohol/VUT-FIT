<?php

declare(strict_types=1);

use Latte\Runtime as LR;

/** source: /home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/UserSystems/createComponentCreateSystemForm.latte */
final class Template4819e48363 extends Latte\Runtime\Template
{
	public const Source = '/home/helheim/FIT/VUT-IIS/iis-project/app/Presenters/templates/UserSystems/createComponentCreateSystemForm.latte';


	public function main(array $ʟ_args): void
	{
		extract($ʟ_args);
		unset($ʟ_args);

		if ($this->global->snippetDriver?->renderSnippets($this->blocks[self::LayerSnippet], $this->params)) {
			return;
		}

		echo '<div class="create-system-form">
    <h2>Create New System</h2>

    <form action="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link('UserSystems:createSystemFormSucceeded')) /* line 4 */;
		echo '" method="post">
        <div>
            <label for="system_name">System Name</label>
            <input type="text" id="system_name" name="system_name" required>
        </div>

        <div>
            <label for="system_description">System Description</label>
            <input type="text" id="system_description" name="system_description" required>
        </div>

        <div>
            <input type="submit" name="submit" value="Create System">
        </div>
    </form>
</div>
';
	}
}
